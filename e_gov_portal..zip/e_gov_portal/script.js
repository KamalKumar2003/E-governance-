// Global variables
let currentLanguage = 'en';
let currentPage = 'dashboard';

// Text content for multilingual support
const textContent = {
    en: {
        title: 'Rural E-Governance Portal',
        subtitle: 'Digital Services for Rural Citizens',
        dashboard: 'Dashboard',
        services: 'Services',
        applications: 'My Applications',
        schemes: 'Government Schemes',
        grievance: 'Grievance',
        contact: 'Contact',
        profile: 'Profile',
        welcome: 'Welcome to Digital Government Services',
        welcomeDesc: 'Access government services from the comfort of your home',
        certificates: 'Certificates',
        welfare: 'Welfare Schemes',
        quickServices: 'Quick Services',
        trackApplication: 'Track Application',
        newApplication: 'New Application',
        downloadForms: 'Download Forms',
        uploadDocuments: 'Upload Documents',
        recentApplications: 'Recent Applications',
        popularServices: 'Popular Services',
        announcements: 'Announcements',
        helpline: 'Helpline: 1800-123-4567',
        applyNow: 'Apply Now',
        trackNow: 'Track Now',
        viewAll: 'View All',
        status: 'Status',
        pending: 'Pending',
        approved: 'Approved',
        rejected: 'Rejected',
        inProgress: 'In Progress'
    },
    hi: {
        title: 'ग्रामीण ई-गवर्नेंस पोर्टल',
        subtitle: 'ग्रामीण नागरिकों के लिए डिजिटल सेवाएं',
        dashboard: 'डैशबोर्ड',
        services: 'सेवाएं',
        applications: 'मेरे आवेदन',
        schemes: 'सरकारी योजनाएं',
        grievance: 'शिकायत',
        contact: 'संपर्क',
        profile: 'प्रोफाइल',
        welcome: 'डिजिटल सरकारी सेवाओं में आपका स्वागत है',
        welcomeDesc: 'अपने घर से सरकारी सेवाओं का लाभ उठाएं',
        certificates: 'प्रमाण पत्र',
        welfare: 'कल्याणकारी योजनाएं',
        quickServices: 'त्वरित सेवाएं',
        trackApplication: 'आवेदन ट्रैक करें',
        newApplication: 'नया आवेदन',
        downloadForms: 'फॉर्म डाउनलोड करें',
        uploadDocuments: 'दस्तावेज अपलोड करें',
        recentApplications: 'हाल के आवेदन',
        popularServices: 'लोकप्रिय सेवाएं',
        announcements: 'घोषणाएं',
        helpline: 'हेल्पलाइन: 1800-123-4567',
        applyNow: 'अभी आवेदन करें',
        trackNow: 'अभी ट्रैक करें',
        viewAll: 'सभी देखें',
        status: 'स्थिति',
        pending: 'लंबित',
        approved: 'स्वीकृत',
        rejected: 'अस्वीकृत',
        inProgress: 'प्रगति में'
    }
};

// Services data
const services = [
    {
        id: 'birth-cert',
        name: 'Birth Certificate',
        nameHi: 'जन्म प्रमाण पत्र',
        description: 'Apply for birth certificate online',
        descriptionHi: 'जन्म प्रमाण पत्र के लिए ऑनलाइन आवेदन करें',
        icon: 'fas fa-file-alt',
        category: 'certificates'
    },
    {
        id: 'death-cert',
        name: 'Death Certificate',
        nameHi: 'मृत्यु प्रमाण पत्र',
        description: 'Apply for death certificate online',
        descriptionHi: 'मृत्यु प्रमाण पत्र के लिए ऑनलाइन आवेदन करें',
        icon: 'fas fa-file-alt',
        category: 'certificates'
    },
    {
        id: 'income-cert',
        name: 'Income Certificate',
        nameHi: 'आय प्रमाण पत्र',
        description: 'Apply for income certificate',
        descriptionHi: 'आय प्रमाण पत्र के लिए आवेदन करें',
        icon: 'fas fa-certificate',
        category: 'certificates'
    },
    {
        id: 'caste-cert',
        name: 'Caste Certificate',
        nameHi: 'जाति प्रमाण पत्र',
        description: 'Apply for caste certificate',
        descriptionHi: 'जाति प्रमाण पत्र के लिए आवेदन करें',
        icon: 'fas fa-certificate',
        category: 'certificates'
    },
    {
        id: 'ration-card',
        name: 'Ration Card',
        nameHi: 'राशन कार्ड',
        description: 'Apply for new ration card',
        descriptionHi: 'नया राशन कार्ड के लिए आवेदन करें',
        icon: 'fas fa-id-card',
        category: 'welfare'
    },
    {
        id: 'pension',
        name: 'Pension Scheme',
        nameHi: 'पेंशन योजना',
        description: 'Apply for pension schemes',
        descriptionHi: 'पेंशन योजनाओं के लिए आवेदन करें',
        icon: 'fas fa-hand-holding-usd',
        category: 'welfare'
    }
];

// Sample applications data
const applications = [
    {
        id: 'APP001',
        service: 'Birth Certificate',
        serviceHi: 'जन्म प्रमाण पत्र',
        date: '2024-01-15',
        status: 'approved',
        progress: 100,
        nextStep: 'Document ready for collection',
        nextStepHi: 'दस्तावेज संग्रह के लिए तैयार'
    },
    {
        id: 'APP002',
        service: 'Income Certificate',
        serviceHi: 'आय प्रमाण पत्र',
        date: '2024-01-10',
        status: 'inProgress',
        progress: 60,
        nextStep: 'Under verification',
        nextStepHi: 'सत्यापन के तहत'
    },
    {
        id: 'APP003',
        service: 'Ration Card',
        serviceHi: 'राशन कार्ड',
        date: '2024-01-08',
        status: 'pending',
        progress: 25,
        nextStep: 'Waiting for document submission',
        nextStepHi: 'दस्तावेज जमा करने की प्रतीक्षा'
    }
];

// Government schemes data
const schemes = [
    {
        id: 'pmay',
        name: 'Pradhan Mantri Awas Yojana',
        nameHi: 'प्रधानमंत्री आवास योजना',
        category: 'Housing',
        categoryHi: 'आवास',
        description: 'Housing scheme for economically weaker sections',
        descriptionHi: 'आर्थिक रूप से कमजोर वर्गों के लिए आवास योजना',
        benefits: [
            'Financial assistance for house construction',
            'Subsidized interest rates',
            'Easy loan approval process'
        ],
        benefitsHi: [
            'घर निर्माण के लिए वित्तीय सहायता',
            'सब्सिडी वाली ब्याज दरें',
            'आसान ऋण अनुमोदन प्रक्रिया'
        ],
        icon: 'fas fa-home'
    },
    {
        id: 'pmkisan',
        name: 'PM-KISAN Scheme',
        nameHi: 'पीएम-किसान योजना',
        category: 'Agriculture',
        categoryHi: 'कृषि',
        description: 'Direct income support to farmers',
        descriptionHi: 'किसानों को प्रत्यक्ष आय सहायता',
        benefits: [
            '₹6000 per year direct transfer',
            'No paperwork required',
            'Automatic enrollment'
        ],
        benefitsHi: [
            '₹6000 प्रति वर्ष प्रत्यक्ष हस्तांतरण',
            'कोई कागजी कार्रवाई आवश्यक नहीं',
            'स्वचालित नामांकन'
        ],
        icon: 'fas fa-seedling'
    },
    {
        id: 'ayushman',
        name: 'Ayushman Bharat',
        nameHi: 'आयुष्मान भारत',
        category: 'Healthcare',
        categoryHi: 'स्वास्थ्य सेवा',
        description: 'Health insurance scheme for poor families',
        descriptionHi: 'गरीब परिवारों के लिए स्वास्थ्य बीमा योजना',
        benefits: [
            '₹5 lakh health coverage',
            'Cashless treatment',
            'Pre and post hospitalization'
        ],
        benefitsHi: [
            '₹5 लाख स्वास्थ्य कवरेज',
            'कैशलेस उपचार',
            'अस्पताल में भर्ती से पहले और बाद'
        ],
        icon: 'fas fa-heartbeat'
    }
];

// DOM elements
const navItems = document.querySelectorAll('.nav-item');
const pages = document.querySelectorAll('.page');
const langToggle = document.getElementById('langToggle');
const mobileMenuToggle = document.getElementById('mobileMenuToggle');
const navMenu = document.getElementById('navMenu');
const loadingOverlay = document.getElementById('loadingOverlay');
const modal = document.getElementById('modal');
const modalClose = document.getElementById('modalClose');

// Initialize the application
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    populateContent();
});

function initializeApp() {
    // Set initial page
    showPage('dashboard');
    
    // Update language toggle text
    updateLanguageToggle();
}

function setupEventListeners() {
    // Navigation items
    navItems.forEach(item => {
        item.addEventListener('click', function() {
            const page = this.getAttribute('data-page');
            showPage(page);
            
            // Update active nav item
            navItems.forEach(nav => nav.classList.remove('active'));
            this.classList.add('active');
            
            // Close mobile menu
            navMenu.classList.remove('active');
        });
    });

    // Language toggle
    langToggle.addEventListener('click', function() {
        toggleLanguage();
    });

    // Mobile menu toggle
    mobileMenuToggle.addEventListener('click', function() {
        navMenu.classList.toggle('active');
    });

    // Modal close
    modalClose.addEventListener('click', function() {
        closeModal();
    });

    // Close modal when clicking outside
    modal.addEventListener('click', function(e) {
        if (e.target === modal) {
            closeModal();
        }
    });

    // Track application button
    const trackBtn = document.getElementById('trackBtn');
    if (trackBtn) {
        trackBtn.addEventListener('click', function() {
            trackApplication();
        });
    }

    // Track grievance button
    const trackGrievanceBtn = document.getElementById('trackGrievanceBtn');
    if (trackGrievanceBtn) {
        trackGrievanceBtn.addEventListener('click', function() {
            trackGrievance();
        });
    }

    // Grievance form submission
    const grievanceForm = document.getElementById('grievanceForm');
    if (grievanceForm) {
        grievanceForm.addEventListener('submit', function(e) {
            e.preventDefault();
            submitGrievance();
        });
    }

    // Hero action buttons
    document.addEventListener('click', function(e) {
        if (e.target.closest('[data-action="new-application"]')) {
            showPage('services');
            updateActiveNav('services');
        }
        
        if (e.target.closest('[data-action="track-application"]')) {
            showPage('applications');
            updateActiveNav('applications');
        }
        
        if (e.target.closest('[data-action="view-services"]')) {
            showPage('services');
            updateActiveNav('services');
        }
    });
}

function showPage(pageId) {
    // Hide all pages
    pages.forEach(page => page.classList.remove('active'));
    
    // Show selected page
    const targetPage = document.getElementById(pageId);
    if (targetPage) {
        targetPage.classList.add('active');
        currentPage = pageId;
    }
}

function updateActiveNav(pageId) {
    navItems.forEach(nav => nav.classList.remove('active'));
    const targetNav = document.querySelector(`[data-page="${pageId}"]`);
    if (targetNav) {
        targetNav.classList.add('active');
    }
}

function toggleLanguage() {
    currentLanguage = currentLanguage === 'en' ? 'hi' : 'en';
    updateLanguageToggle();
    populateContent();
}

function updateLanguageToggle() {
    const langText = langToggle.querySelector('span');
    langText.textContent = currentLanguage === 'en' ? 'हिंदी' : 'English';
}

function populateContent() {
    populatePopularServices();
    populateRecentApplications();
    populateCertificateServices();
    populateWelfareServices();
    populateApplicationsDetailed();
    populateSchemes();
}

function populatePopularServices() {
    const container = document.getElementById('popularServices');
    if (!container) return;

    const popularServicesHtml = services.slice(0, 6).map(service => `
        <div class="popular-service" onclick="applyForService('${service.id}')">
            <div class="popular-service-header">
                <div class="popular-service-icon">
                    <i class="${service.icon}"></i>
                </div>
                <div>
                    <h3>${currentLanguage === 'en' ? service.name : service.nameHi}</h3>
                </div>
            </div>
            <p>${currentLanguage === 'en' ? service.description : service.descriptionHi}</p>
            <button class="apply-btn">
                ${textContent[currentLanguage].applyNow}
            </button>
        </div>
    `).join('');

    container.innerHTML = popularServicesHtml;
}

function populateRecentApplications() {
    const container = document.getElementById('recentApplications');
    if (!container) return;

    const applicationsHtml = applications.map(app => `
        <div class="application-item">
            <div class="application-info">
                <div class="application-icon">
                    <i class="fas fa-file-alt"></i>
                </div>
                <div class="application-details">
                    <h4>${currentLanguage === 'en' ? app.service : app.serviceHi}</h4>
                    <p>Application ID: ${app.id}</p>
                    <p>Applied on: ${app.date}</p>
                </div>
            </div>
            <div class="status-badge status-${app.status}">
                <i class="fas ${getStatusIcon(app.status)}"></i>
                ${textContent[currentLanguage][app.status]}
            </div>
        </div>
    `).join('');

    container.innerHTML = applicationsHtml;
}

function populateCertificateServices() {
    const container = document.getElementById('certificateServices');
    if (!container) return;

    const certificateServices = services.filter(s => s.category === 'certificates');
    const servicesHtml = certificateServices.map(service => `
        <div class="category-service" onclick="applyForService('${service.id}')">
            <div class="category-service-info">
                <i class="${service.icon}"></i>
                <div>
                    <h3>${currentLanguage === 'en' ? service.name : service.nameHi}</h3>
                    <p>${currentLanguage === 'en' ? service.description : service.descriptionHi}</p>
                </div>
            </div>
            <button class="btn btn-info">
                ${textContent[currentLanguage].applyNow}
            </button>
        </div>
    `).join('');

    container.innerHTML = servicesHtml;
}

function populateWelfareServices() {
    const container = document.getElementById('welfareServices');
    if (!container) return;

    const welfareServices = services.filter(s => s.category === 'welfare');
    const servicesHtml = welfareServices.map(service => `
        <div class="category-service" onclick="applyForService('${service.id}')">
            <div class="category-service-info">
                <i class="${service.icon}"></i>
                <div>
                    <h3>${currentLanguage === 'en' ? service.name : service.nameHi}</h3>
                    <p>${currentLanguage === 'en' ? service.description : service.descriptionHi}</p>
                </div>
            </div>
            <button class="btn btn-success">
                ${textContent[currentLanguage].applyNow}
            </button>
        </div>
    `).join('');

    container.innerHTML = servicesHtml;
}

function populateApplicationsDetailed() {
    const container = document.getElementById('applicationsDetailed');
    if (!container) return;

    const applicationsHtml = applications.map(app => `
        <div class="application-detailed">
            <div class="application-header">
                <div>
                    <h3 class="application-title">${currentLanguage === 'en' ? app.service : app.serviceHi}</h3>
                    <p class="application-id">Application ID: ${app.id}</p>
                    <p class="application-date">Applied on: ${app.date}</p>
                </div>
                <div class="status-badge status-${app.status}">
                    <i class="fas ${getStatusIcon(app.status)}"></i>
                    ${textContent[currentLanguage][app.status]}
                </div>
            </div>
            
            <div class="progress-section">
                <div class="progress-header">
                    <span>Progress</span>
                    <span>${app.progress}%</span>
                </div>
                <div class="progress-bar">
                    <div class="progress-fill progress-${app.status}" style="width: ${app.progress}%"></div>
                </div>
            </div>
            
            <div class="application-footer">
                <p class="next-step">${currentLanguage === 'en' ? app.nextStep : app.nextStepHi}</p>
                <button class="view-details-btn" onclick="viewApplicationDetails('${app.id}')">
                    View Details
                </button>
            </div>
        </div>
    `).join('');

    container.innerHTML = applicationsHtml;
}

function populateSchemes() {
    const container = document.getElementById('schemesGrid');
    if (!container) return;

    const schemesHtml = schemes.map(scheme => `
        <div class="scheme-card">
            <div class="scheme-header">
                <div class="scheme-icon">
                    <i class="${scheme.icon}"></i>
                </div>
                <div>
                    <h3 class="scheme-title">${currentLanguage === 'en' ? scheme.name : scheme.nameHi}</h3>
                    <p class="scheme-category">${currentLanguage === 'en' ? scheme.category : scheme.categoryHi}</p>
                </div>
            </div>
            <p class="scheme-description">${currentLanguage === 'en' ? scheme.description : scheme.descriptionHi}</p>
            <div class="scheme-benefits">
                <h4>Key Benefits:</h4>
                <ul>
                    ${(currentLanguage === 'en' ? scheme.benefits : scheme.benefitsHi).map(benefit => `<li>${benefit}</li>`).join('')}
                </ul>
            </div>
            <button class="btn btn-primary" onclick="applyForScheme('${scheme.id}')">
                ${textContent[currentLanguage].applyNow}
            </button>
        </div>
    `).join('');

    container.innerHTML = schemesHtml;
}

function getStatusIcon(status) {
    switch (status) {
        case 'approved': return 'fa-check-circle';
        case 'inProgress': return 'fa-clock';
        case 'pending': return 'fa-exclamation-circle';
        default: return 'fa-question-circle';
    }
}

function applyForService(serviceId) {
    showLoading();
    
    setTimeout(() => {
        hideLoading();
        const service = services.find(s => s.id === serviceId);
        if (service) {
            showModal(
                `Apply for ${currentLanguage === 'en' ? service.name : service.nameHi}`,
                `
                <p>You are about to apply for <strong>${currentLanguage === 'en' ? service.name : service.nameHi}</strong>.</p>
                <p>Required documents:</p>
                <ul>
                    <li>Identity Proof (Aadhaar Card)</li>
                    <li>Address Proof</li>
                    <li>Passport Size Photo</li>
                    <li>Supporting Documents</li>
                </ul>
                <div style="margin-top: 20px;">
                    <button class="btn btn-primary" onclick="proceedWithApplication('${serviceId}')">
                        Proceed with Application
                    </button>
                    <button class="btn btn-secondary" onclick="closeModal()" style="margin-left: 10px;">
                        Cancel
                    </button>
                </div>
                `
            );
        }
    }, 1000);
}

function applyForScheme(schemeId) {
    showLoading();
    
    setTimeout(() => {
        hideLoading();
        const scheme = schemes.find(s => s.id === schemeId);
        if (scheme) {
            showModal(
                `Apply for ${currentLanguage === 'en' ? scheme.name : scheme.nameHi}`,
                `
                <p>You are about to apply for <strong>${currentLanguage === 'en' ? scheme.name : scheme.nameHi}</strong>.</p>
                <p>This scheme offers:</p>
                <ul>
                    ${(currentLanguage === 'en' ? scheme.benefits : scheme.benefitsHi).map(benefit => `<li>${benefit}</li>`).join('')}
                </ul>
                <div style="margin-top: 20px;">
                    <button class="btn btn-primary" onclick="proceedWithSchemeApplication('${schemeId}')">
                        Check Eligibility & Apply
                    </button>
                    <button class="btn btn-secondary" onclick="closeModal()" style="margin-left: 10px;">
                        Cancel
                    </button>
                </div>
                `
            );
        }
    }, 1000);
}

function proceedWithApplication(serviceId) {
    closeModal();
    showLoading();
    
    setTimeout(() => {
        hideLoading();
        showModal(
            'Application Submitted Successfully',
            `
            <div style="text-align: center;">
                <i class="fas fa-check-circle" style="font-size: 3rem; color: #28a745; margin-bottom: 20px;"></i>
                <h3>Application Submitted!</h3>
                <p>Your application has been submitted successfully.</p>
                <p><strong>Application ID:</strong> APP${Date.now().toString().slice(-6)}</p>
                <p>You will receive updates via SMS and email.</p>
                <button class="btn btn-primary" onclick="closeModal()">
                    OK
                </button>
            </div>
            `
        );
    }, 2000);
}

function proceedWithSchemeApplication(schemeId) {
    closeModal();
    showLoading();
    
    setTimeout(() => {
        hideLoading();
        showModal(
            'Eligibility Check Complete',
            `
            <div style="text-align: center;">
                <i class="fas fa-check-circle" style="font-size: 3rem; color: #28a745; margin-bottom: 20px;"></i>
                <h3>You are Eligible!</h3>
                <p>Congratulations! You meet the eligibility criteria for this scheme.</p>
                <p><strong>Application ID:</strong> SCH${Date.now().toString().slice(-6)}</p>
                <p>Your application has been forwarded for processing.</p>
                <button class="btn btn-primary" onclick="closeModal()">
                    OK
                </button>
            </div>
            `
        );
    }, 2000);
}

function trackApplication() {
    const trackingId = document.getElementById('trackingId').value.trim();
    
    if (!trackingId) {
        alert('Please enter an Application ID');
        return;
    }
    
    showLoading();
    
    setTimeout(() => {
        hideLoading();
        
        // Simulate tracking result
        const mockResult = {
            id: trackingId,
            service: 'Birth Certificate',
            status: 'inProgress',
            progress: 75,
            lastUpdate: '2024-01-20',
            nextStep: 'Document verification in progress'
        };
        
        showModal(
            'Application Status',
            `
            <div>
                <h4>Application ID: ${mockResult.id}</h4>
                <p><strong>Service:</strong> ${mockResult.service}</p>
                <p><strong>Status:</strong> <span class="status-badge status-${mockResult.status}">${textContent[currentLanguage][mockResult.status]}</span></p>
                <p><strong>Progress:</strong> ${mockResult.progress}%</p>
                <div class="progress-bar" style="margin: 10px 0;">
                    <div class="progress-fill progress-${mockResult.status}" style="width: ${mockResult.progress}%"></div>
                </div>
                <p><strong>Last Update:</strong> ${mockResult.lastUpdate}</p>
                <p><strong>Next Step:</strong> ${mockResult.nextStep}</p>
                <button class="btn btn-primary" onclick="closeModal()" style="margin-top: 15px;">
                    Close
                </button>
            </div>
            `
        );
    }, 1500);
}

function trackGrievance() {
    const grievanceId = document.getElementById('grievanceTrackingId').value.trim();
    
    if (!grievanceId) {
        alert('Please enter a Grievance ID');
        return;
    }
    
    showLoading();
    
    setTimeout(() => {
        hideLoading();
        
        showModal(
            'Grievance Status',
            `
            <div>
                <h4>Grievance ID: ${grievanceId}</h4>
                <p><strong>Type:</strong> Service Delay</p>
                <p><strong>Status:</strong> <span class="status-badge status-inProgress">Under Review</span></p>
                <p><strong>Filed on:</strong> 2024-01-18</p>
                <p><strong>Expected Resolution:</strong> 2024-01-25</p>
                <p><strong>Assigned Officer:</strong> District Collector Office</p>
                <button class="btn btn-primary" onclick="closeModal()" style="margin-top: 15px;">
                    Close
                </button>
            </div>
            `
        );
    }, 1500);
}

function submitGrievance() {
    const formData = {
        type: document.getElementById('grievanceType').value,
        subject: document.getElementById('grievanceSubject').value,
        description: document.getElementById('grievanceDescription').value,
        file: document.getElementById('grievanceFile').files[0]
    };
    
    if (!formData.type || !formData.subject || !formData.description) {
        alert('Please fill in all required fields');
        return;
    }
    
    showLoading();
    
    setTimeout(() => {
        hideLoading();
        
        // Reset form
        document.getElementById('grievanceForm').reset();
        
        showModal(
            'Grievance Submitted Successfully',
            `
            <div style="text-align: center;">
                <i class="fas fa-check-circle" style="font-size: 3rem; color: #28a745; margin-bottom: 20px;"></i>
                <h3>Grievance Submitted!</h3>
                <p>Your grievance has been submitted successfully.</p>
                <p><strong>Grievance ID:</strong> GRV${Date.now().toString().slice(-6)}</p>
                <p>You will receive updates on the resolution progress.</p>
                <p><strong>Expected Resolution:</strong> 7-10 working days</p>
                <button class="btn btn-primary" onclick="closeModal()">
                    OK
                </button>
            </div>
            `
        );
    }, 2000);
}

function viewApplicationDetails(applicationId) {
    const app = applications.find(a => a.id === applicationId);
    if (!app) return;
    
    showModal(
        'Application Details',
        `
        <div>
            <h4>${currentLanguage === 'en' ? app.service : app.serviceHi}</h4>
            <p><strong>Application ID:</strong> ${app.id}</p>
            <p><strong>Applied on:</strong> ${app.date}</p>
            <p><strong>Current Status:</strong> <span class="status-badge status-${app.status}">${textContent[currentLanguage][app.status]}</span></p>
            <p><strong>Progress:</strong> ${app.progress}%</p>
            <div class="progress-bar" style="margin: 10px 0;">
                <div class="progress-fill progress-${app.status}" style="width: ${app.progress}%"></div>
            </div>
            <p><strong>Next Step:</strong> ${currentLanguage === 'en' ? app.nextStep : app.nextStepHi}</p>
            
            <h5 style="margin-top: 20px;">Timeline:</h5>
            <ul style="list-style: none; padding: 0;">
                <li style="margin-bottom: 10px;">
                    <i class="fas fa-check-circle" style="color: #28a745;"></i>
                    Application Submitted - ${app.date}
                </li>
                <li style="margin-bottom: 10px;">
                    <i class="fas fa-clock" style="color: #ffc107;"></i>
                    Document Verification - In Progress
                </li>
                <li style="margin-bottom: 10px;">
                    <i class="fas fa-circle" style="color: #ccc;"></i>
                    Approval Process - Pending
                </li>
                <li style="margin-bottom: 10px;">
                    <i class="fas fa-circle" style="color: #ccc;"></i>
                    Document Ready - Pending
                </li>
            </ul>
            
            <button class="btn btn-primary" onclick="closeModal()" style="margin-top: 15px;">
                Close
            </button>
        </div>
        `
    );
}

function showModal(title, content) {
    document.getElementById('modalTitle').textContent = title;
    document.getElementById('modalBody').innerHTML = content;
    modal.classList.add('active');
}

function closeModal() {
    modal.classList.remove('active');
}

function showLoading() {
    loadingOverlay.classList.add('active');
}

function hideLoading() {
    loadingOverlay.classList.remove('active');
}

// Utility functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-IN');
}

function generateApplicationId() {
    return 'APP' + Date.now().toString().slice(-6);
}

// Service worker registration for offline functionality
if ('serviceWorker' in navigator) {
    window.addEventListener('load', function() {
        navigator.serviceWorker.register('/sw.js')
            .then(function(registration) {
                console.log('ServiceWorker registration successful');
            })
            .catch(function(err) {
                console.log('ServiceWorker registration failed');
            });
    });
}