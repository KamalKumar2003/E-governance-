<?php
include 'db.php';

$user_id = $_POST['user_id'];
$service_type = $_POST['service_type'];

$sql = "INSERT INTO applications (user_id, service_type) VALUES ('$user_id', '$service_type')";
if ($conn->query($sql) === TRUE) {
    echo "Application submitted successfully!";
} else {
    echo "Error: " . $conn->error;
}
?>
